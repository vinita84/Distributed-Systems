import threading
from socket import *

class Server(object):
    def __init__(self, port, host):
        self.host = host
        self.port = port
        self.serverSocket = socket(AF_INET,SOCK_STREAM)
        self.serverSocket.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
        self.serverSocket.bind((host, port))
        self.sendValue = ''
        self.globalDict = {}
        self.lock = threading.Lock()


    def writedata(self, receivedpacket, connectionsocket):
        self.lock.acquire()
        receivedpacket = receivedpacket.split(' ')
        if len(receivedpacket) > 1:
            if '=' in receivedpacket[1]:
                receivedpacket = receivedpacket[1].split('=')
                if len(receivedpacket)>1 and receivedpacket[0] not in self.globalDict:
                    self.globalDict[receivedpacket[0]] = receivedpacket[1]
                    self.sendValue = "Saved Successfully for key:" + receivedpacket[0]
                elif receivedpacket[0] in self.globalDict:
                    self.globalDict[receivedpacket[0]] = receivedpacket[1]
                    self.sendValue = "Update Successfully for key:" + receivedpacket[0]
                else:
                    self.sendValue = "error occurred in saving key:" + receivedpacket[0]
        self.lock.release()
        connectionsocket.send(self.sendValue.encode())
        connectionsocket.close()
        return

    def connectclient(self):
       self.serverSocket.listen(1)
       print('The server is ready to receive')
       while 1:
           receivedpacket = []
           self.sendValue = ''
           connectionsocket, addr = self.serverSocket.accept()
           receivedpacket = connectionsocket.recv(2048).decode()

           # GET fetches from the dictionary
           if 'GET' in receivedpacket:
               receivedpacket = receivedpacket.split(' ')
               if len(receivedpacket) > 1:
                   if receivedpacket[1] in self.globalDict:
                       self.sendValue = self.globalDict[receivedpacket[1]]
                   else:
                       self.sendValue = 'Invalid Key:' + receivedpacket[1]
               connectionsocket.send(self.sendValue.encode())
               connectionsocket.close()

           # STORE write to the dictionary
           elif 'STORE' in receivedpacket:
               t = threading.Thread(target=self.writedata, args=(receivedpacket,connectionsocket))
               t.start()

           # if QUIT is received break
           elif 'QUIT' in receivedpacket:
               self.sendValue = "Server Quitting.."
               connectionsocket.send(self.sendValue.encode())
               connectionsocket.close()
               break
       self.serverSocket.close()
       return

if __name__ == '__main__':
    serverPort = 12000
    host = '127.0.0.1'
    Server(serverPort, host).connectclient()