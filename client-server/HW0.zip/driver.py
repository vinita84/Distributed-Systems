import os
import time
import server
import alice
import bob

def main():
    # shared_checkpoint = 1
    server_pid = os.fork()
    if server_pid > 0:
        time.sleep(4)  # Making sure the server is up and running before the clients are forked
        pid = os.fork()
        if pid > 0:
            # time.sleep(10)  # Giving time
            pid = os.fork()
            if pid == 0:
                time.sleep(5)
                # call bob.py client for different test cases
                print("\n TEST CASE: Bob GET foo")
                bob.run_bob(['--key=foo'])

                print('\n TEST CASE: Bob STORE foo-bob=foo-bob-val-bob')
                bob.run_bob(['--key=foo-bob', '--value=foo-bob-val-bob'])
                # time.sleep(10)

                print('\n TEST CASE (CONCURRENCY): Bob STORE foo=foo-val-bob ')
                bob.run_bob(['--key=foo', '--value=foo-val-bob'])

                print("\n Sending STOP SERVER message to Bob")
                bob.run_bob(['--key=QUIT'])

        elif pid == 0:
            # call alice.py client for different test cases
            print('\n TEST CASE: Alice STORE foo=foo-val-none')
            alice.run_alice(['--key=foo', '--value=foo-val-none'])

            print('\n TEST CASE (INVALID KEY): Alice GET abc')
            alice.run_alice(['--key=abc'])
            # time.sleep(10)

            print('\n TEST CASE (CONCURRENCY): Alice STORE foo=foo-val-alice')
            alice.run_alice(['--key=foo', '--value=foo-val-alice'])

            print("\n TEST CASE: Alice GET foo")
            alice.run_alice(['--key=foo'])
            # shared_checkpoint += 2
            # time.sleep(10)

    elif server_pid == 0:
        print('\n Server Starting')
        serverPort = 12000
        host = '127.0.0.1'
        (server.Server(serverPort, host)).connectclient()
        print("\n\n Drives ends")
    pass

if __name__ == '__main__':
    main()
